
from flask import Flask, request, render_template_string
import subprocess

app = Flask(__name__)
SCRIPT_PATH = "../eyesy/main.py"

EDITOR_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Eyesy Live Editor</title>
    <style>#editor { height: 90vh; width: 100%; }</style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js"></script>
</head>
<body>
    <h2>Eyesy Live Coding (main.py)</h2>
    <form method="POST">
        <div id="editor">{{ code|safe }}</div>
        <textarea name="code" id="codeArea" style="display:none;"></textarea>
        <button type="submit">Save & Reload</button>
    </form>
    <script>
        var editor = ace.edit("editor");
        editor.session.setMode("ace/mode/python");
        document.querySelector("form").onsubmit = function() {
            document.getElementById("codeArea").value = editor.getValue();
        };
    </script>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def edit_script():
    if request.method == "POST":
        new_code = request.form["code"]
        with open(SCRIPT_PATH, "w") as f:
            f.write(new_code)
        subprocess.Popen(["pkill", "-f", "main.py"])
        subprocess.Popen(["python3", SCRIPT_PATH])
    with open(SCRIPT_PATH, "r") as f:
        code = f.read()
    return render_template_string(EDITOR_TEMPLATE, code=code)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

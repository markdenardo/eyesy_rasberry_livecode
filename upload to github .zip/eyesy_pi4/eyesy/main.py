
import pygame
import pygame.midi
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import time

# Visual parameter controlled by MIDI CC
param_brightness = 1.0

def init_midi():
    pygame.midi.init()
    input_id = pygame.midi.get_default_input_id()
    return pygame.midi.Input(input_id)

def read_midi(midi_in):
    if midi_in.poll():
        data = midi_in.read(1)
        _, status, cc, value = data[0][0]
        if status & 0xF0 == 0xB0:  # MIDI CC message
            return cc, value
    return None, None

def draw_square(brightness):
    glBegin(GL_QUADS)
    glColor3f(1.0 * brightness, 0.2 * brightness, 0.2 * brightness)
    glVertex2f(-0.5, -0.5)
    glColor3f(0.2 * brightness, 1.0 * brightness, 0.2 * brightness)
    glVertex2f(0.5, -0.5)
    glColor3f(0.2 * brightness, 0.2 * brightness, 1.0 * brightness)
    glVertex2f(0.5, 0.5)
    glColor3f(1.0 * brightness, 1.0 * brightness, 0.0 * brightness)
    glVertex2f(-0.5, 0.5)
    glEnd()

def main():
    global param_brightness
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(-1, 1, -1, 1)
    glMatrixMode(GL_MODELVIEW)

    midi_in = init_midi()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        cc, val = read_midi(midi_in)
        if cc == 7:  # Brightness control
            param_brightness = max(0.0, min(1.0, val / 127.0))

        glClear(GL_COLOR_BUFFER_BIT)
        draw_square(param_brightness)
        pygame.display.flip()
        time.sleep(0.01)

    pygame.midi.quit()
    pygame.quit()

if __name__ == "__main__":
    main()

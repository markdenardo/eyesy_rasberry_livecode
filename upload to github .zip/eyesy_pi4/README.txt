
# 🌀 Eyesy Raspberry Pi Visual Synth (w/ MIDI + Live Web Editor)

This project turns your Raspberry Pi 4 or 5 into a portable visual synth powered by Python and OpenGL, with MIDI CC control from the Dirtywave M8 and a live-editable Python editor accessible via your iPhone.

---

## 📦 What's Inside

- `eyesy_pi4/` — Setup for Raspberry Pi 4
- `eyesy_pi5/` — Setup for Raspberry Pi 5

Each contains:
- `eyesy/` — Python visual synth engine with OpenGL + MIDI CC input
- `flask_editor/` — Web-based live code editor for `main.py`
- `install.sh` — Installs all required Python and system packages
- `start.sh` — Starts the Eyesy synth
- `connect_to_hotspot.sh` — Connects your Pi to an iPhone hotspot (edit SSID/password)
- `README.txt` — You’re reading it!

---

## 🧰 Requirements

- Raspberry Pi 4 or 5 with Raspberry Pi OS (Bookworm recommended)
- HDMI display for visuals
- Internet access (temporarily) to install dependencies
- Dirtywave M8 (via USB for MIDI)
- iPhone (for hotspot and browser editing)

---

## 🚀 Installation Steps

1. **Flash Raspberry Pi OS** to a microSD card and boot it.

2. **Transfer the appropriate folder** to your Pi (`eyesy_pi4/` or `eyesy_pi5/`).

3. SSH into the Pi or open terminal.

4. Run the installer:
   ```bash
   cd eyesy_pi4     # or eyesy_pi5
   bash install.sh
   ```

5. Run the synth:
   ```bash
   bash start.sh
   ```

---

## 🎛️ MIDI Control with Dirtywave M8

- Plug the M8 into your Pi via USB
- Start the Eyesy synth
- Send MIDI CC 7 from the M8 to control **brightness**

You can customize more CCs inside `eyesy/main.py`.

---

## 🌐 Edit Visuals From Your iPhone

1. On the Pi:
   ```bash
   cd flask_editor
   python3 editor.py
   ```

2. On your iPhone, connect to the **same Wi-Fi** as the Pi and visit:
   ```
   http://<your-pi-ip>:5000
   ```

3. Make changes to `main.py` and click “Save & Reload” — the visuals update instantly!

---

## 📡 Auto-Connect Pi to iPhone Hotspot

1. Edit the file `connect_to_hotspot.sh`:
   ```bash
   SSID="Your_iPhone_SSID"
   PASSWORD="Your_iPhone_Password"
   ```

2. Run it once to configure the connection:
   ```bash
   bash connect_to_hotspot.sh
   ```

The Pi will then auto-connect to your iPhone’s hotspot on future boots.

---

## 🛠️ Tips

- To auto-start the synth or editor on boot, use a systemd service or add lines to `/etc/rc.local`.
- You can add `tmux` to keep both the synth and editor running in parallel.

---

Enjoy building audio-reactive visuals controlled from a pocket tracker, edited wirelessly from your phone 🔥

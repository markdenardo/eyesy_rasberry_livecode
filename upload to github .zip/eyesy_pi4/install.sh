
#!/bin/bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-pip python3-pygame python3-opengl     libsdl2-dev libasound2-dev libjack-jackd2-dev     git cmake libgl1-mesa-dev libgles2-mesa-dev pulseaudio

echo "Installing Eyesy dependencies complete."

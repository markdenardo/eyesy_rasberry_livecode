
#!/bin/bash
SSID="Your_iPhone_SSID"
PASSWORD="Your_iPhone_Pass"

sudo tee /etc/wpa_supplicant/wpa_supplicant.conf > /dev/null <<EOF
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
country=US

network={
    ssid="\${SSID}"
    psk="\${PASSWORD}"
    key_mgmt=WPA-PSK
    priority=10
}
EOF

sudo wpa_cli -i wlan0 reconfigure
echo "🟢 iPhone hotspot config applied."


#!/bin/bash
cd "$(dirname "$0")/eyesy"
python3 main.py
